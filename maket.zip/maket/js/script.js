const title = document.querySelector('.title');
const aEL = document.querySelector('.enter');
const blockEl = document.querySelector('.login');

aEL.addEventListener('click', function (e) {blockEl.classList.toggle('visible')})